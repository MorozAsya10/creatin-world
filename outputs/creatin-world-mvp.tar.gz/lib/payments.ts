import { CreatorStatus, PaymentStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getFeatureFlags } from "@/lib/config";

type TestPaymentInput = {
  userId: string;
  clientProfileId?: string;
  creatorProfileId?: string;
  packageId?: string;
  orderId?: string;
  amountCents?: number;
};

export async function createTestPayment(input: TestPaymentInput) {
  const flags = await getFeatureFlags();
  const status = flags.paymentsRequired ? PaymentStatus.CREATED : PaymentStatus.SUCCEEDED;

  const payment = await prisma.payment.create({
    data: {
      userId: input.userId,
      clientProfileId: input.clientProfileId,
      creatorProfileId: input.creatorProfileId,
      packageId: input.packageId,
      orderId: input.orderId,
      amountCents: input.amountCents,
      status,
      testPayload: {
        provider: "test",
        autoSucceeded: status === PaymentStatus.SUCCEEDED,
        featureFlag: flags.paymentsRequired ? "payments.required:on" : "payments.required:off"
      }
    }
  });

  if (status === PaymentStatus.SUCCEEDED) {
    if (input.creatorProfileId) {
      const nextStatus = flags.moderationRequired ? CreatorStatus.MODERATION : CreatorStatus.APPROVED;
      await prisma.creatorProfile.update({
        where: { id: input.creatorProfileId },
        data: {
          membershipPaid: true,
          status: nextStatus,
          isApproved: nextStatus === CreatorStatus.APPROVED
        }
      });
    }

    if (input.clientProfileId && input.packageId) {
      const selectedPackage = await prisma.package.findUnique({ where: { id: input.packageId } });
      await prisma.clientProfile.update({
        where: { id: input.clientProfileId },
        data: {
          activePackageId: input.packageId,
          hasDatabaseAccess: selectedPackage?.databaseAccess ?? false
        }
      });
    }
  }

  return payment;
}
