import { Role } from "@prisma/client";
import { z } from "zod";
import { ok, fail } from "@/lib/api";
import { getFeatureFlags } from "@/lib/config";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";

const schema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  city: z.string().optional(),
  category: z.string().min(2),
  primaryRole: z.string().min(2),
  level: z.string().min(2),
  experienceYears: z.number().int().min(0),
  expertise: z.array(z.string()).default([]),
  bio: z.string().min(10),
  portfolioUrl: z.string().optional(),
  cases: z.string().optional(),
  workFormat: z.string().min(2),
  availability: z.string().min(2),
  minBudget: z.number().int().min(0),
  hourlyRate: z.number().int().min(0).optional(),
  email: z.string().email().or(z.literal("")).optional()
});

export async function PUT(request: Request) {
  try {
    const user = await requireUser([Role.CREATOR]);
    const body = schema.parse(await request.json());
    const flags = await getFeatureFlags();
    const { email, ...profileData } = body;
    const profile = await prisma.$transaction(async (tx) => {
      if (email !== undefined) {
        await tx.user.update({
          where: { id: user.id },
          data: { email: email || null }
        });
      }

      return tx.creatorProfile.update({
        where: { userId: user.id },
        data: {
          ...profileData,
          status: flags.moderationRequired ? "MODERATION" : "APPROVED",
          isApproved: !flags.moderationRequired
        }
      });
    });

    return ok({ profile });
  } catch (error) {
    return fail(error);
  }
}
