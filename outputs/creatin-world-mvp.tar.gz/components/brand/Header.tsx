"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, LogOut, Plus, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { ThemeControl } from "@/components/ui/ThemeControl";
import type { ApiUser } from "@/lib/types";

function initials(name?: string) {
  return (name || "CW")
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

function roleLabel(role?: string) {
  if (role === "CREATOR") return "Креатор";
  if (role === "CLIENT") return "Заказчик";
  if (role === "ADMIN") return "Администратор";
  return "";
}

export function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<ApiUser | null>(null);

  useEffect(() => {
    fetch("/api/auth/session")
      .then((response) => response.json())
      .then((data: { user: ApiUser | null }) => setUser(data.user))
      .catch(() => setUser(null));
  }, [pathname]);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    router.push("/");
    router.refresh();
  }

  return (
    <header className="header">
      <Link className="logo" href="/">
        CREATIN<span>.</span>WORLD
      </Link>
      <nav className="main-nav">
        <Link className={`navbtn ${pathname === "/" ? "active" : ""}`} href="/">
          О платформе
        </Link>
        <Link className={`navbtn ${pathname === "/creators" ? "active" : ""}`} href="/creators">
          Креаторы
        </Link>
        <Link className={`navbtn ${pathname === "/jobs" ? "active" : ""}`} href="/jobs">
          Вакансии
        </Link>
        {user?.role === "ADMIN" ? <Link className={`navbtn ${pathname === "/admin" ? "active" : ""}`} href="/admin">Админка</Link> : null}
      </nav>
      <div className="header-actions">
        <ThemeControl compact />
        {!user ? (
          <>
            <Link className="btn public-secondary" href="/login?role=creator">
              Стать креатором
            </Link>
            <Link className="btn wine" href="/login?role=client">
              Разместить заказ
            </Link>
          </>
        ) : (
          <>
            {user.role === "CLIENT" ? (
              <Link className="btn wine contextual-cta" href="/platform?pane=newOrder">
                <Plus size={16} /> Новый заказ
              </Link>
            ) : user.role === "ADMIN" ? (
              <Link className="btn wine contextual-cta" href="/admin">
                <ShieldCheck size={16} /> Админка
              </Link>
            ) : (
              <Link className="btn contextual-cta" href="/platform?pane=applications">
                Мои отклики
              </Link>
            )}
            <Link className="btn header-cabinet" href={user.role === "ADMIN" ? "/admin" : "/platform"} aria-label={user.role === "ADMIN" ? "Админ-панель" : "Кабинет"}>
              <LayoutDashboard size={16} /><span>Кабинет</span>
            </Link>
            <span className="role-pill">{roleLabel(user.role)}</span>
            <div className="avatar" title={user.name}>
              {initials(user.name)}
            </div>
            <button className="btn ghost icon" onClick={logout} title="Выйти" aria-label="Выйти">
              <LogOut size={16} />
            </button>
          </>
        )}
      </div>
    </header>
  );
}
