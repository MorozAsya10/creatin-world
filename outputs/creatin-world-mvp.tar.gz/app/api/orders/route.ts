import { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { z } from "zod";
import { ok, fail, ApiError } from "@/lib/api";
import { getFeatureFlags } from "@/lib/config";
import { prisma } from "@/lib/prisma";
import { getCurrentUser, requireUser } from "@/lib/session";

const createOrderSchema = z.object({
  title: z.string().min(3),
  category: z.string().min(2),
  description: z.string().min(10),
  requirements: z.string().min(3),
  budget: z.string().min(2),
  deadline: z.string().min(2),
  initiator: z.enum(["CLIENT", "CREATOR"]).default("CLIENT"),
  clientProfileId: z.string().cuid().optional()
});

async function nextPublicId() {
  const orders = await prisma.order.findMany({ select: { publicId: true } });
  const maxNumber = orders.reduce((max, order) => {
    const number = Number(order.publicId.match(/^ORD-(\d+)$/)?.[1] || 0);
    return Math.max(max, number);
  }, 21);

  return `ORD-${String(maxNumber + 1).padStart(3, "0")}`;
}

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    const scope = request.nextUrl.searchParams.get("scope") || "public";
    const where =
      scope === "mine" && user?.role === Role.CLIENT && user.clientProfile
        ? { clientProfileId: user.clientProfile.id }
        : scope === "admin" && user?.role === Role.ADMIN
          ? {}
          : { status: "PUBLISHED" as const };

    const orders = await prisma.order.findMany({
      where,
      include: {
        clientProfile: true,
        _count: { select: { applications: true } },
        aiMatches: {
          orderBy: { rank: "asc" },
          include: { creatorProfile: { include: { user: true } } }
        }
      },
      orderBy: { createdAt: "desc" }
    });

    return ok({ orders });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireUser([Role.CLIENT, Role.ADMIN]);
    const body = createOrderSchema.parse(await request.json());
    const flags = await getFeatureFlags();

    const clientProfile = user.role === Role.CLIENT
      ? user.clientProfile
      : body.clientProfileId
        ? await prisma.clientProfile.findUnique({ where: { id: body.clientProfileId } })
        : null;

    if (!clientProfile) {
      throw new ApiError(400, user.role === Role.ADMIN ? "Выберите заказчика" : "Заполните карточку компании");
    }

    const status = user.role === Role.ADMIN
      ? "PUBLISHED"
      : flags.moderationRequired
        ? "MODERATION"
        : "PUBLISHED";

    const order = await prisma.order.create({
      data: {
        title: body.title,
        category: body.category,
        description: body.description,
        requirements: body.requirements,
        budget: body.budget,
        deadline: body.deadline,
        initiator: body.initiator,
        publicId: await nextPublicId(),
        clientProfileId: clientProfile.id,
        status,
        paymentRequired: flags.paymentsRequired,
        moderationRequired: user.role === Role.CLIENT && flags.moderationRequired,
        publishedAt: status === "PUBLISHED" ? new Date() : null
      }
    });

    return ok({ order }, { status: 201 });
  } catch (error) {
    return fail(error);
  }
}
