import { prisma } from "@/lib/prisma";

export type FeatureFlags = {
  paymentsRequired: boolean;
  moderationRequired: boolean;
  aiExternalRequired: boolean;
};

const envFlag = (key: string) => process.env[key] === "true";

export const defaultFeatureFlags: FeatureFlags = {
  paymentsRequired: envFlag("FEATURE_PAYMENTS_REQUIRED"),
  moderationRequired: envFlag("FEATURE_MODERATION_REQUIRED"),
  aiExternalRequired: envFlag("FEATURE_AI_EXTERNAL_REQUIRED")
};

const dbFlagKey: Record<keyof FeatureFlags, string> = {
  paymentsRequired: "payments.required",
  moderationRequired: "moderation.required",
  aiExternalRequired: "ai.external_required"
};

export async function getFeatureFlags(): Promise<FeatureFlags> {
  try {
    const rows = await prisma.featureFlag.findMany();
    const byKey = new Map(rows.map((flag) => [flag.key, flag.enabled]));

    return {
      paymentsRequired: byKey.get(dbFlagKey.paymentsRequired) ?? defaultFeatureFlags.paymentsRequired,
      moderationRequired:
        byKey.get(dbFlagKey.moderationRequired) ?? defaultFeatureFlags.moderationRequired,
      aiExternalRequired:
        byKey.get(dbFlagKey.aiExternalRequired) ?? defaultFeatureFlags.aiExternalRequired
    };
  } catch {
    return defaultFeatureFlags;
  }
}
