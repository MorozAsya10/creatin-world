import { Suspense } from "react";
import { Role } from "@prisma/client";
import { redirect } from "next/navigation";
import { PlatformShell } from "@/components/platform/PlatformShell";
import { getCurrentUser } from "@/lib/session";

export default async function PlatformPage() {
  const user = await getCurrentUser();
  if (user?.role === Role.ADMIN) redirect("/admin");

  return (
    <Suspense fallback={<section className="section fill"><div className="loading">Загружаем кабинет...</div></section>}>
      <PlatformShell />
    </Suspense>
  );
}
