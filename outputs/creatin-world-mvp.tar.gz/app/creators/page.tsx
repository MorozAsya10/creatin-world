import { CreatorCatalog } from "@/components/catalog/CreatorCatalog";

export default function CreatorsPage() {
  return (
    <section className="section fill">
      <div className="section-head">
        <div>
          <div className="eyebrow">Открытый каталог</div>
          <h2>Проверенные креаторы</h2>
        </div>
        <p className="section-copy">
          До покупки доступа заказчик видит профили и портфолио, но контакты зависят от выбранного пакета.
        </p>
      </div>
      <CreatorCatalog scope="public" />
    </section>
  );
}
