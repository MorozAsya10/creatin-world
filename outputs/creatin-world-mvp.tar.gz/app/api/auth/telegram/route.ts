import { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { ok, fail, ApiError } from "@/lib/api";
import { prisma } from "@/lib/prisma";
import { normalizeTelegramUser, verifyTelegramPayload, type TelegramLoginPayload } from "@/lib/telegram";
import { setSessionCookie } from "@/lib/session";

async function ensureRoleProfile(userId: string, role: Role, telegramUsername?: string) {
  if (role === Role.CREATOR) {
    await prisma.creatorProfile.upsert({
      where: { userId },
      update: {},
      create: {
        userId,
        firstName: "Анна",
        lastName: "Ким",
        city: "Москва",
        category: "Дизайн",
        primaryRole: "Motion / 3D designer",
        level: "Senior",
        experienceYears: 7,
        expertise: ["3D", "Motion", "Fashion"],
        bio: "Создаю визуальные системы и 3D-ролики для брендов.",
        portfolioUrl: "https://portfolio.example",
        cases: "1. Fashion campaign\n2. 3D product film\n3. Brand launch",
        workFormat: "Проект",
        availability: "available",
        minBudget: 180000,
        hourlyRate: 10000,
        telegramContact: telegramUsername ? `@${telegramUsername}` : "@annakim",
        status: "APPROVED",
        membershipPaid: true,
        isApproved: true,
        score: 96
      }
    });
  }

  if (role === Role.CLIENT) {
    await prisma.clientProfile.upsert({
      where: { userId },
      update: {},
      create: {
        userId,
        companyName: "NORTH STUDIO",
        website: "north.example",
        industry: "Fashion / E-commerce",
        description: "Независимый бренд и digital-команда.",
        contactName: "Никита Романов",
        contactTitle: "Founder",
        legalType: "Юридическое лицо",
        inn: "7700000000"
      }
    });
  }
}

export async function POST(request: NextRequest) {
  try {
    const payload = (await request.json()) as TelegramLoginPayload;
    verifyTelegramPayload(payload);
    const normalized = normalizeTelegramUser(payload);

    const existing = await prisma.user.findUnique({
      where: { telegramId: normalized.telegramId }
    });

    const configuredAdminIds = new Set(
      (process.env.TELEGRAM_ADMIN_IDS || "")
        .split(",")
        .map((id) => id.trim())
        .filter(Boolean)
    );
    const isDemoAdmin =
      process.env.TELEGRAM_AUTH_BYPASS === "true" && normalized.telegramId === "90001";
    const canCreateAdmin = configuredAdminIds.has(normalized.telegramId) || isDemoAdmin;

    if (normalized.role === Role.ADMIN && existing?.role !== Role.ADMIN && !canCreateAdmin) {
      throw new ApiError(403, "Этот Telegram-аккаунт не добавлен в список администраторов");
    }

    const role = existing?.role || normalized.role;
    const user = await prisma.user.upsert({
      where: { telegramId: normalized.telegramId },
      update: {
        telegramUsername: normalized.telegramUsername,
        name: normalized.name,
        role
      },
      create: {
        telegramId: normalized.telegramId,
        telegramUsername: normalized.telegramUsername,
        name: normalized.name,
        role
      }
    });

    await ensureRoleProfile(user.id, user.role, user.telegramUsername || undefined);
    await setSessionCookie(user);

    const withProfiles = await prisma.user.findUnique({
      where: { id: user.id },
      include: { creatorProfile: true, clientProfile: true }
    });

    return ok({ user: withProfiles });
  } catch (error) {
    return fail(error);
  }
}
