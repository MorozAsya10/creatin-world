import { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { ok, fail } from "@/lib/api";
import { getFeatureFlags } from "@/lib/config";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

export async function GET(request: NextRequest) {
  try {
    const params = request.nextUrl.searchParams;
    const category = params.get("category") || "Все";
    const level = params.get("level") || "";
    const workFormat = params.get("format") || "";
    const availability = params.get("availability") || "";
    const budget = params.get("budget") || "";
    const search = (params.get("search") || "").toLowerCase();

    const [creators, user, flags] = await Promise.all([
      prisma.creatorProfile.findMany({
      where: {
        isApproved: true,
        ...(category !== "Все" ? { category } : {}),
        ...(level ? { level } : {}),
        ...(workFormat ? { workFormat } : {}),
        ...(availability ? { availability } : {})
      },
      include: {
        user: true,
        files: true
      },
      orderBy: [{ score: "desc" }, { experienceYears: "desc" }]
      }),
      getCurrentUser(),
      getFeatureFlags()
    ]);

    const canSeeContacts =
      user?.role === Role.ADMIN ||
      (user?.role === Role.CLIENT &&
        (!flags.paymentsRequired || Boolean(user.clientProfile?.hasDatabaseAccess)));

    const filtered = creators.filter((creator) => {
      const budgetMatches =
        !budget ||
        (budget === "low" && creator.minBudget < 100000) ||
        (budget === "mid" && creator.minBudget >= 100000 && creator.minBudget <= 200000) ||
        (budget === "high" && creator.minBudget > 200000);

      const haystack = [
        creator.firstName,
        creator.lastName,
        creator.primaryRole,
        creator.bio,
        creator.category,
        creator.expertise.join(" ")
      ]
        .join(" ")
        .toLowerCase();

      return budgetMatches && (!search || haystack.includes(search));
    });

    return ok({
      creators: filtered.map((creator) => ({
        ...creator,
        telegramContact: canSeeContacts ? creator.telegramContact : null,
        user: canSeeContacts
          ? {
              telegramUsername: creator.user.telegramUsername
            }
          : undefined
      })),
      canSeeContacts
    });
  } catch (error) {
    return fail(error);
  }
}
