"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Send } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

type LoginRole = "creator" | "client" | "admin";

type TelegramWidgetUser = {
  id: string;
  first_name?: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
  auth_date?: string;
  hash?: string;
};

declare global {
  interface Window {
    onCreatinTelegramAuth?: (user: TelegramWidgetUser) => void;
  }
}

const roleCopy: Record<LoginRole, { title: string; text: string; name: string; id: string; username: string }> = {
  creator: {
    title: "Я креатор",
    text: "Ищу проекты, хочу вступить в сообщество.",
    name: "Анна",
    id: "10001",
    username: "annakim"
  },
  client: {
    title: "Я заказчик",
    text: "Хочу размещать заказы и находить исполнителей.",
    name: "Никита",
    id: "20001",
    username: "northfounder"
  },
  admin: {
    title: "Администратор",
    text: "Управляю пользователями, модерацией, платежами и AI-логами.",
    name: "CREATIN",
    id: "90001",
    username: "creatin_admin"
  }
};

export function TelegramLogin({ demoEnabled }: { demoEnabled: boolean }) {
  const router = useRouter();
  const params = useSearchParams();
  const widgetRef = useRef<HTMLDivElement>(null);
  const initialRole = (params.get("role") as LoginRole) || "creator";
  const [role, setRole] = useState<LoginRole>(["creator", "client", "admin"].includes(initialRole) ? initialRole : "creator");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const botUsername = process.env.NEXT_PUBLIC_TELEGRAM_BOT_USERNAME;

  const roles = useMemo(() => Object.entries(roleCopy) as Array<[LoginRole, (typeof roleCopy)[LoginRole]]>, []);

  async function submitTelegram(payload: TelegramWidgetUser, requestedRole: LoginRole = role) {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/auth/telegram", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ...payload, requestedRole })
      });

      if (!response.ok) {
        const data = (await response.json()) as { error?: string };
        setError(data.error || "Не удалось войти через Telegram");
        return;
      }

      const data = (await response.json()) as { user?: { role?: "CREATOR" | "CLIENT" | "ADMIN" } };
      router.replace(data.user?.role === "ADMIN" ? "/admin" : "/platform");
      router.refresh();
    } catch {
      setError("Сервер входа недоступен. Проверьте PostgreSQL и повторите попытку.");
    } finally {
      setLoading(false);
    }
  }

  async function demoLogin(demoRole: LoginRole = role) {
    const selected = roleCopy[demoRole];
    await submitTelegram({
      id: selected.id,
      first_name: selected.name,
      last_name: demoRole === "creator" ? "Ким" : demoRole === "client" ? "Романов" : "Admin",
      username: selected.username,
      auth_date: String(Math.floor(Date.now() / 1000)),
      hash: "dev-bypass"
    }, demoRole);
  }

  useEffect(() => {
    const requestedRole = params.get("role") as LoginRole | null;
    if (requestedRole && ["creator", "client", "admin"].includes(requestedRole)) {
      setRole(requestedRole);
      setError("");
    }
  }, [params]);

  useEffect(() => {
    if (!botUsername || !widgetRef.current) return;

    window.onCreatinTelegramAuth = (user) => {
      void submitTelegram(user);
    };

    widgetRef.current.innerHTML = "";
    const script = document.createElement("script");
    script.async = true;
    script.src = "https://telegram.org/js/telegram-widget.js?22";
    script.setAttribute("data-telegram-login", botUsername);
    script.setAttribute("data-size", "large");
    script.setAttribute("data-userpic", "false");
    script.setAttribute("data-request-access", "write");
    script.setAttribute("data-onauth", "onCreatinTelegramAuth(user)");
    widgetRef.current.appendChild(script);
  }, [botUsername, role]);

  return (
    <div className="auth-screen">
      <div className="auth-card">
        <div className="eyebrow">Единая регистрация</div>
        <h2>Войти через Telegram</h2>
        <p>
          Telegram подтверждает личность пользователя. Анкета креатора, карточка компании
          или административный доступ открываются после входа внутри платформы.
        </p>
        <div className="auth-role-grid">
          {roles.map(([key, item]) => (
            <button
              key={key}
              className={`auth-role ${role === key ? "selected" : ""}`}
              disabled={loading}
              onClick={() => {
                setRole(key);
                setError("");
                router.replace(`/login?role=${key}`, { scroll: false });
                if (demoEnabled) void demoLogin(key);
              }}
            >
              <b>{item.title}</b>
              <span>{item.text}</span>
            </button>
          ))}
        </div>
        {demoEnabled ? (
          <button className="telegram" onClick={() => void demoLogin()} disabled={loading}>
            <Send size={16} /> {loading ? "Входим..." : role === "admin" ? "Открыть админ-панель" : `Открыть кабинет ${role === "creator" ? "креатора" : "заказчика"}`}
          </button>
        ) : null}
        {error ? <div className="notice error-notice" role="alert">{error}</div> : null}
        {!demoEnabled ? <div className="telegram-widget-slot" ref={widgetRef} aria-label="Telegram Login widget" /> : null}
      </div>
    </div>
  );
}
