"use client";

import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  BookOpen,
  Bot,
  Briefcase,
  Building2,
  CreditCard,
  FileText,
  Inbox,
  LayoutDashboard,
  MessageSquare,
  Plus,
  Settings,
  Sparkles,
  Users
} from "lucide-react";
import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import { CreatorCatalog } from "@/components/catalog/CreatorCatalog";
import { CreatorProfileDialog } from "@/components/catalog/CreatorProfileDialog";
import { SelectControl } from "@/components/ui/SelectControl";
import { ThemeControl } from "@/components/ui/ThemeControl";
import { formatFileSize, orderInitiatorLabel, statusLabel } from "@/lib/presentation";
import type {
  ApiUser,
  Application,
  Chat,
  CreatorProfile,
  FeatureFlags,
  Invitation,
  Order,
  PackagePlan
} from "@/lib/types";

type Bootstrap = {
  user: ApiUser | null;
  flags: FeatureFlags;
  packages: PackagePlan[];
  stats: { creators: number; publishedOrders: number };
};

type MenuItem = {
  id: string;
  label: string;
  group: string;
  icon: React.ReactNode;
};

const roleLabel = {
  CREATOR: "Креатор",
  CLIENT: "Заказчик",
  ADMIN: "Администратор"
};

function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

function formatMoney(cents?: number | null) {
  if (!cents) return "Цена уточняется";
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
    maximumFractionDigits: 0
  }).format(cents / 100);
}

async function responseError(response: Response, fallback: string) {
  try {
    const data = (await response.json()) as { error?: string };
    return data.error || fallback;
  } catch {
    return fallback;
  }
}

function creatorMenu(): MenuItem[] {
  return [
    { id: "overview", label: "Обзор", group: "Креатор", icon: <LayoutDashboard size={16} /> },
    { id: "jobs", label: "Вакансии", group: "Креатор", icon: <Briefcase size={16} /> },
    { id: "applications", label: "Мои отклики", group: "Креатор", icon: <Inbox size={16} /> },
    { id: "invites", label: "Приглашения", group: "Креатор", icon: <Sparkles size={16} /> },
    { id: "community", label: "Сообщество", group: "Креатор", icon: <Users size={16} /> },
    { id: "knowledge", label: "База знаний", group: "Креатор", icon: <BookOpen size={16} /> },
    { id: "creatorOnboarding", label: "Анкета креатора", group: "Личный кабинет", icon: <FileText size={16} /> },
    { id: "chats", label: "Чаты по заказам", group: "Личный кабинет", icon: <MessageSquare size={16} /> },
    { id: "settings", label: "Настройки", group: "Личный кабинет", icon: <Settings size={16} /> }
  ];
}

function clientMenu(): MenuItem[] {
  return [
    { id: "overview", label: "Обзор", group: "Заказчик", icon: <LayoutDashboard size={16} /> },
    { id: "newOrder", label: "Создать заказ", group: "Заказчик", icon: <Plus size={16} /> },
    { id: "orders", label: "Мои заказы", group: "Заказчик", icon: <Briefcase size={16} /> },
    { id: "responses", label: "Отклики", group: "Заказчик", icon: <Inbox size={16} /> },
    { id: "catalog", label: "Каталог креаторов", group: "Заказчик", icon: <Users size={16} /> },
    { id: "companyOnboarding", label: "Карточка компании", group: "Личный кабинет", icon: <Building2 size={16} /> },
    { id: "chats", label: "Чаты по заказам", group: "Личный кабинет", icon: <MessageSquare size={16} /> },
    { id: "payments", label: "Оплата и пакеты", group: "Финансы", icon: <CreditCard size={16} /> },
    { id: "settings", label: "Настройки", group: "Личный кабинет", icon: <Settings size={16} /> }
  ];
}

function adminMenu(): MenuItem[] {
  return [
    { id: "overview", label: "Админ-обзор", group: "Администрирование", icon: <LayoutDashboard size={16} /> },
    { id: "orders", label: "Заказы", group: "Администрирование", icon: <Briefcase size={16} /> },
    { id: "catalog", label: "Креаторы", group: "Администрирование", icon: <Users size={16} /> },
    { id: "settings", label: "Настройки продукта", group: "Администрирование", icon: <Settings size={16} /> }
  ];
}

export function PlatformShell() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialPane = searchParams.get("pane") || "overview";
  const [bootstrap, setBootstrap] = useState<Bootstrap | null>(null);
  const [pane, setPane] = useState(initialPane);
  const [orders, setOrders] = useState<Order[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [chats, setChats] = useState<Chat[]>([]);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(searchParams.get("orderId"));
  const [activeChatId, setActiveChatId] = useState<string | null>(searchParams.get("chatId"));
  const [toast, setToast] = useState("");
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState("");

  const user = bootstrap?.user || null;

  const menu = useMemo(() => {
    if (user?.role === "CLIENT") return clientMenu();
    if (user?.role === "ADMIN") return adminMenu();
    return creatorMenu();
  }, [user?.role]);

  const groupedMenu = useMemo(() => {
    return menu.reduce<Record<string, MenuItem[]>>((acc, item) => {
      acc[item.group] = acc[item.group] || [];
      acc[item.group].push(item);
      return acc;
    }, {});
  }, [menu]);

  async function loadBootstrap() {
    const response = await fetch("/api/bootstrap");
    if (!response.ok) throw new Error(await responseError(response, "Не удалось загрузить платформу"));
    const data = (await response.json()) as Bootstrap;
    setBootstrap(data);
    return data;
  }

  async function loadRoleData(currentUser: ApiUser) {
    const orderScope = currentUser.role === "CLIENT" ? "mine" : currentUser.role === "ADMIN" ? "admin" : "public";
    const [ordersResponse, applicationsResponse, invitationsResponse, chatsResponse] = await Promise.all([
      fetch(`/api/orders?scope=${orderScope}`),
      currentUser.role === "ADMIN" ? Promise.resolve(null) : fetch("/api/applications"),
      fetch("/api/invitations"),
      fetch("/api/chats")
    ]);

    if (!ordersResponse.ok) throw new Error(await responseError(ordersResponse, "Не удалось загрузить заказы"));
    if (applicationsResponse && !applicationsResponse.ok) {
      throw new Error(await responseError(applicationsResponse, "Не удалось загрузить отклики"));
    }
    if (!invitationsResponse.ok) {
      throw new Error(await responseError(invitationsResponse, "Не удалось загрузить приглашения"));
    }
    if (!chatsResponse.ok) throw new Error(await responseError(chatsResponse, "Не удалось загрузить чаты"));

    const ordersData = (await ordersResponse.json()) as { orders: Order[] };
    setOrders(ordersData.orders || []);

    if (applicationsResponse) {
      const appsData = (await applicationsResponse.json()) as { applications: Application[] };
      setApplications(appsData.applications || []);
    }

    const invitationsData = (await invitationsResponse.json()) as { invitations: Invitation[] };
    setInvitations(invitationsData.invitations || []);

    const chatsData = (await chatsResponse.json()) as { chats: Chat[] };
    setChats(chatsData.chats || []);
    setActiveChatId((current) =>
      current && chatsData.chats?.some((chat) => chat.id === current)
        ? current
        : chatsData.chats?.[0]?.id || null
    );
  }

  function showToast(message: string) {
    setToast(message);
    setTimeout(() => setToast(""), 2400);
  }

  function openPane(nextPane: string) {
    setPane(nextPane);
    router.replace(`/platform?pane=${nextPane}`, { scroll: false });
  }

  function openOrder(orderId: string) {
    setSelectedOrderId(orderId);
    setPane("orderDetail");
    router.replace(`/platform?pane=orderDetail&orderId=${encodeURIComponent(orderId)}`, { scroll: false });
  }

  function openChat(chatId: string) {
    setActiveChatId(chatId);
    setPane("chats");
    router.replace(`/platform?pane=chats&chatId=${encodeURIComponent(chatId)}`, { scroll: false });
  }

  async function refreshAll() {
    try {
      setLoadError("");
      const nextBootstrap = await loadBootstrap();
      if (nextBootstrap.user) await loadRoleData(nextBootstrap.user);
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "Не удалось обновить данные");
    }
  }

  useEffect(() => {
    void refreshAll();
  }, []);

  useEffect(() => {
    const requestedPane = searchParams.get("pane") || "overview";
    setPane(requestedPane);
    setSelectedOrderId(searchParams.get("orderId"));
    const requestedChatId = searchParams.get("chatId");
    if (requestedChatId) setActiveChatId(requestedChatId);
  }, [searchParams]);

  useEffect(() => {
    const isClientOrderDetail = user?.role === "CLIENT" && pane === "orderDetail";
    if (user && !menu.some((item) => item.id === pane) && !isClientOrderDetail) {
      openPane("overview");
    }
  }, [user?.role, pane, menu]);

  if (!bootstrap && !loadError) {
    return <div className="section fill"><div className="loading">Загружаем кабинет...</div></div>;
  }

  if (!bootstrap) {
    return (
      <section className="section fill">
        <div className="panel">
          <div className="panel-body">
            <h2 className="page-title">Не удалось загрузить кабинет</h2>
            <p className="page-copy">{loadError}</p>
            <button className="btn wine" type="button" onClick={() => void refreshAll()} style={{ marginTop: 16 }}>
              Повторить
            </button>
          </div>
        </div>
      </section>
    );
  }

  if (!user) {
    return (
      <section className="section fill">
        <div className="panel">
          <div className="panel-body">
            <div className="eyebrow">Требуется вход</div>
            <h2 className="page-title">Кабинет открывается через Telegram</h2>
            <p className="page-copy">Выберите роль и войдите, чтобы увидеть рабочие разделы платформы.</p>
            <div className="hero-actions">
              <Link className="btn wine" href="/login?role=creator">Войти как креатор</Link>
              <Link className="btn" href="/login?role=client">Войти как заказчик</Link>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const content =
    user.role === "CREATOR"
      ? renderCreatorPane({
          pane,
          user,
          orders,
          applications,
          invitations,
          chats,
          selectedOrderId,
          activeChatId,
          setActiveChatId,
          setBusy,
          busy,
          refreshAll,
          showToast,
          openPane,
          openOrder,
          openChat,
          flags: bootstrap.flags
        })
      : user.role === "CLIENT"
        ? renderClientPane({
            pane,
            user,
            orders,
            applications,
            invitations,
            chats,
            selectedOrderId,
            activeChatId,
            setActiveChatId,
            setBusy,
            busy,
            refreshAll,
            showToast,
            openPane,
            openOrder,
            openChat,
            packages: bootstrap.packages,
            flags: bootstrap.flags
          })
        : renderAdminLitePane({ pane, flags: bootstrap.flags, openPane });

  return (
    <section className="platform">
      <aside className="sidebar">
        <div className="side-user">
          <div className="avatar">{initials(user.name)}</div>
          <div>
            <b>{user.name}</b>
            <span>{roleLabel[user.role]}</span>
          </div>
        </div>
        {Object.entries(groupedMenu).map(([group, items]) => (
          <div className={`side-group ${group === "Финансы" ? "bottom" : ""}`} key={group}>
            <div className="side-title">{group}</div>
            {items.map((item) => (
              <button
                key={item.id}
                className={`sidebtn ${pane === item.id ? "active" : ""}`}
                onClick={() => (user.role === "ADMIN" && item.id === "overview" ? router.push("/admin") : openPane(item.id))}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </div>
        ))}
      </aside>
      <div className="work">{content}</div>
      <div className={`toast ${toast || loadError ? "show" : ""}`} role="status">{toast || loadError}</div>
    </section>
  );
}

type PaneContext = {
  pane: string;
  user: ApiUser;
  orders: Order[];
  applications: Application[];
  invitations: Invitation[];
  chats: Chat[];
  selectedOrderId: string | null;
  activeChatId: string | null;
  setActiveChatId: (id: string) => void;
  setBusy: (busy: boolean) => void;
  busy: boolean;
  refreshAll: () => Promise<void>;
  showToast: (message: string) => void;
  openPane: (pane: string) => void;
  openOrder: (orderId: string) => void;
  openChat: (chatId: string) => void;
  flags: FeatureFlags;
};

function renderCreatorPane(ctx: PaneContext) {
  if (ctx.pane === "creatorOnboarding") return <CreatorOnboarding {...ctx} />;
  if (ctx.pane === "jobs") return <CreatorJobs {...ctx} />;
  if (ctx.pane === "applications") return <CreatorApplications {...ctx} />;
  if (ctx.pane === "invites") return <InvitesPane {...ctx} />;
  if (ctx.pane === "community") return <CommunityPane />;
  if (ctx.pane === "knowledge") return <KnowledgePane />;
  if (ctx.pane === "chats") return <ChatPane {...ctx} />;
  if (ctx.pane === "settings") return <SettingsPane {...ctx} />;
  return <CreatorOverview {...ctx} />;
}

function renderClientPane(ctx: PaneContext & { packages: PackagePlan[]; flags: FeatureFlags }) {
  if (ctx.pane === "companyOnboarding") return <CompanyOnboarding {...ctx} />;
  if (ctx.pane === "newOrder") return <NewOrderPane {...ctx} />;
  if (ctx.pane === "orders") return <ClientOrders {...ctx} />;
  if (ctx.pane === "orderDetail") return <ClientOrderDetail {...ctx} />;
  if (ctx.pane === "responses") return <ClientResponses {...ctx} />;
  if (ctx.pane === "catalog") return <ClientCatalog {...ctx} />;
  if (ctx.pane === "chats") return <ChatPane {...ctx} />;
  if (ctx.pane === "payments") return <PaymentPane {...ctx} />;
  if (ctx.pane === "settings") return <SettingsPane {...ctx} />;
  return <ClientOverview {...ctx} />;
}

function renderAdminLitePane({ pane, flags, openPane }: { pane: string; flags: FeatureFlags; openPane: (pane: string) => void }) {
  if (pane === "catalog") {
    return (
      <>
        <div className="page-head">
          <div>
            <h2 className="page-title">Креаторы</h2>
            <p className="page-copy">Административный просмотр каталога с видимыми контактами.</p>
          </div>
        </div>
        <CreatorCatalog scope="client" canSeeContacts />
      </>
    );
  }

  if (pane === "orders") {
    return (
      <div className="panel">
        <div className="panel-body">
          <div className="eyebrow">Администрирование</div>
          <h2 className="page-title">Заказы и модерация</h2>
          <p className="page-copy">Полная административная панель находится на отдельной странице.</p>
          <Link className="btn wine" href="/admin" style={{ marginTop: 16 }}>
            Открыть админку
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="page-head">
        <div>
          <h2 className="page-title">Настройки продукта</h2>
          <p className="page-copy">Управление доступностью ключевых процессов платформы.</p>
        </div>
        <button className="btn" onClick={() => openPane("catalog")}>Каталог</button>
      </div>
      <div className="summary summary-three">
        <div className="metric"><span>Оплата</span><b>{flags.paymentsRequired ? "Обязательна" : "Открыта"}</b></div>
        <div className="metric"><span>Модерация</span><b>{flags.moderationRequired ? "Обязательна" : "Открыта"}</b></div>
        <div className="metric"><span>AI-подбор</span><b>{flags.aiExternalRequired ? "Только внешний" : "С резервом"}</b></div>
      </div>
    </>
  );
}

function CreatorOverview(ctx: PaneContext) {
  const appliedOrderIds = new Set(ctx.applications.map((application) => application.order?.id).filter(Boolean));
  const recommendedOrders = ctx.orders.filter(
    (order) => order.status === "PUBLISHED" && !appliedOrderIds.has(order.id)
  );
  const pendingInvitations = ctx.invitations.filter((invitation) => invitation.status === "SENT");

  return (
    <>
      <div className="page-head">
        <div>
          <h2 className="page-title">Добро пожаловать, {ctx.user.creatorProfile?.firstName || ctx.user.name}</h2>
          <p className="page-copy">Новые вакансии, отклики и приглашения.</p>
        </div>
      </div>
      <div className="summary">
        <div className="metric"><span>Подходящие вакансии</span><b>{recommendedOrders.length}</b></div>
        <div className="metric"><span>Активные отклики</span><b>{ctx.applications.filter((item) => !["REJECTED", "ACCEPTED"].includes(item.status)).length}</b></div>
        <div className="metric"><span>Новые приглашения</span><b>{pendingInvitations.length}</b></div>
        <div className="metric"><span>Чаты по заказам</span><b>{ctx.chats.length}</b></div>
      </div>
      <div style={{ height: 14 }} />
      <div className="grid two">
        <div className="panel">
          <div className="panel-head"><span className="panel-title">Рекомендованные вакансии</span></div>
          <div className="panel-body">
            {recommendedOrders.length
              ? recommendedOrders.slice(0, 2).map((order) => <JobSnippet key={order.id} order={order} />)
              : <div className="empty compact">Новых вакансий без отклика пока нет.</div>}
          </div>
        </div>
        <div className="panel">
          <div className="panel-head"><span className="panel-title">Последняя активность</span></div>
          <div className="panel-body">
            {ctx.chats[0] ? <div className="feed-item"><div className="meta">{ctx.chats[0].order.publicId}</div><h3>Открыт чат по заказу</h3><p>{ctx.chats[0].order.title}</p></div> : null}
            {pendingInvitations[0] ? <div className="feed-item"><div className="meta">{pendingInvitations[0].order.publicId}</div><h3>Новое приглашение</h3><p>{pendingInvitations[0].order.title}</p></div> : null}
            {!ctx.chats.length && !pendingInvitations.length ? <div className="empty compact">Новых событий пока нет.</div> : null}
          </div>
        </div>
      </div>
    </>
  );
}

function CreatorOnboarding(ctx: PaneContext) {
  const profile = ctx.user.creatorProfile;
  const [uploading, setUploading] = useState(false);
  const profileComplete = Boolean(profile?.firstName && profile.lastName && profile.bio && profile.expertise.length);
  const paymentComplete = !ctx.flags.paymentsRequired || Boolean(profile?.membershipPaid);
  const moderationComplete = !ctx.flags.moderationRequired || Boolean(profile?.isApproved);
  const completedSteps = [profileComplete, paymentComplete, moderationComplete, profileComplete && paymentComplete && moderationComplete].filter(Boolean).length;
  const progress = completedSteps * 25;

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    ctx.setBusy(true);
    try {
      const response = await fetch("/api/profiles/creator", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          firstName: String(form.get("firstName")),
          lastName: String(form.get("lastName")),
          email: String(form.get("email")),
          city: String(form.get("city")),
          category: String(form.get("category")),
          primaryRole: String(form.get("primaryRole")),
          level: String(form.get("level")),
          experienceYears: Number(form.get("experienceYears")),
          expertise: String(form.get("expertise")).split(",").map((item) => item.trim()).filter(Boolean),
          bio: String(form.get("bio")),
          portfolioUrl: String(form.get("portfolioUrl")),
          cases: String(form.get("cases")),
          workFormat: String(form.get("workFormat")),
          availability: String(form.get("availability")),
          minBudget: Number(form.get("minBudget")),
          hourlyRate: Number(form.get("hourlyRate"))
        })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось сохранить анкету"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast(ctx.flags.moderationRequired ? "Анкета отправлена на модерацию" : "Анкета сохранена и опубликована");
    } finally {
      ctx.setBusy(false);
    }
  }

  async function payMembership() {
    ctx.setBusy(true);
    try {
      const response = await fetch("/api/payments/test", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ purpose: "creator_membership" })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось активировать вступление"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast("Тестовое вступление активировано");
    } finally {
      ctx.setBusy(false);
    }
  }

  async function uploadPortfolio(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);
    setUploading(true);
    try {
      const response = await fetch("/api/files/portfolio", {
        method: "POST",
        body: formData
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось загрузить файл"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast("Файл добавлен в портфолио");
    } finally {
      setUploading(false);
      event.target.value = "";
    }
  }

  return (
    <>
      <div className="page-head">
        <div>
          <h2 className="page-title">Анкета креатора</h2>
          <p className="page-copy">Профиль, по которому заказчики и AI находят подходящих специалистов.</p>
        </div>
        <span className={`status ${profile?.isApproved ? "ok" : "warn"}`}>{statusLabel(profile?.status || "DRAFT")}</span>
      </div>
      <div className="onboarding">
        <div className="onboarding-steps">
          <div className="meta">Прогресс {progress}%</div>
          <div className="progress"><span style={{ width: `${progress}%` }} /></div>
          <div className={`on-step ${profileComplete ? "done" : "active"}`}><b>01</b> Профессиональная анкета</div>
          <div className={`on-step ${paymentComplete ? "done" : "active"}`}><b>02</b> {ctx.flags.paymentsRequired ? "Оплата вступления" : "Оплата отключена"}</div>
          <div className={`on-step ${moderationComplete ? "done" : "active"}`}><b>03</b> {ctx.flags.moderationRequired ? "Модерация" : "Модерация отключена"}</div>
          <div className={`on-step ${progress === 100 ? "done" : ""}`}><b>04</b> Доступ к платформе</div>
        </div>
        <form className="panel" onSubmit={submit}>
          <div className="panel-body">
            <div className="form-section">
              <h3>Основная информация</h3>
              <div className="form-grid">
                <div className="form-row">
                  <label>Файлы портфолио</label>
                  <label className="upload interactive">
                    <input className="visually-hidden" type="file" accept=".pdf,.jpg,.jpeg,.png,.webp,.mp4" onChange={uploadPortfolio} disabled={uploading} />
                    {uploading ? "Загружаем..." : "Выбрать PDF, изображение или MP4 до 15 МБ"}
                  </label>
                  <div className="file-list">
                    {profile?.files?.map((file) => (
                      <a className="file-row" href={file.url} target="_blank" rel="noreferrer" key={file.id}>
                        <FileText size={15} /><span>{file.fileName}</span><small>{formatFileSize(file.size)}</small>
                      </a>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="form-row"><label>Имя</label><input name="firstName" defaultValue={profile?.firstName || "Анна"} /></div>
                  <div className="form-row"><label>Фамилия</label><input name="lastName" defaultValue={profile?.lastName || "Ким"} /></div>
                  <div className="form-row"><label>Telegram</label><input value={`@${ctx.user.telegramUsername || "annakim"}`} disabled /></div>
                  <div className="form-row"><label>Email</label><input name="email" type="email" defaultValue={ctx.user.email || ""} placeholder="name@example.com" /></div>
                </div>
                <div className="form-row"><label>Город</label><input name="city" defaultValue={profile?.city || "Москва"} /></div>
                <div className="form-row"><label>Портфолио</label><input name="portfolioUrl" defaultValue={profile?.portfolioUrl || "https://portfolio.example"} /></div>
              </div>
            </div>
            <div className="form-section">
              <h3>Специализация</h3>
              <div className="form-grid">
                <div className="form-row"><label>Категория</label><SelectControl name="category" defaultValue={profile?.category || "Дизайн"}><option>Дизайн</option><option>Видео</option><option>Креатив</option><option>AI</option><option>Маркетинг</option></SelectControl></div>
                <div className="form-row"><label>Основная роль</label><input name="primaryRole" defaultValue={profile?.primaryRole || "Motion / 3D designer"} /></div>
                <div className="form-row"><label>Уровень</label><SelectControl name="level" defaultValue={profile?.level || "Senior"}><option>Junior</option><option>Middle</option><option>Senior</option></SelectControl></div>
                <div className="form-row"><label>Опыт, лет</label><input name="experienceYears" type="number" defaultValue={profile?.experienceYears || 7} /></div>
                <div className="form-row full"><label>Экспертиза через запятую</label><textarea name="expertise" defaultValue={(profile?.expertise || ["3D", "Motion", "Fashion"]).join(", ")} /></div>
              </div>
            </div>
            <div className="form-section">
              <h3>О себе и условия</h3>
              <div className="form-row"><label>О себе</label><textarea name="bio" defaultValue={profile?.bio || "Создаю визуальные системы и 3D-ролики для брендов."} /></div>
              <div className="form-row"><label>Кейсы</label><textarea name="cases" defaultValue={profile?.cases || "1. Fashion campaign\n2. 3D product film\n3. Brand launch"} /></div>
              <div className="form-grid">
                <div className="form-row"><label>Формат</label><SelectControl name="workFormat" defaultValue={profile?.workFormat || "Проект"}><option>Проект</option><option>Part-time</option></SelectControl></div>
                <div className="form-row"><label>Доступность</label><SelectControl name="availability" defaultValue={profile?.availability || "available"}><option value="available">Свободен сейчас</option><option value="soon">Свободен скоро</option></SelectControl></div>
                <div className="form-row"><label>Минимальный чек, ₽</label><input name="minBudget" type="number" defaultValue={profile?.minBudget || 180000} /></div>
                <div className="form-row"><label>Ставка, ₽/час</label><input name="hourlyRate" type="number" defaultValue={profile?.hourlyRate || 10000} /></div>
              </div>
            </div>
            <div className="hero-actions">
              <button className="btn wine" disabled={ctx.busy}>{ctx.busy ? "Сохраняем..." : "Сохранить анкету"}</button>
              {ctx.flags.paymentsRequired && !profile?.membershipPaid ? <button className="btn" type="button" onClick={payMembership} disabled={ctx.busy}>Тестовое вступление</button> : <span className="status ok">Оплата не блокирует доступ</span>}
            </div>
          </div>
        </form>
      </div>
    </>
  );
}

function CreatorJobs(ctx: PaneContext) {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const appliedByOrder = new Map(
    ctx.applications
      .filter((application) => application.order)
      .map((application) => [application.order!.id, application])
  );

  async function apply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedOrder) return;
    const form = new FormData(event.currentTarget);
    ctx.setBusy(true);
    try {
      const price = Number(form.get("price"));
      const response = await fetch(`/api/orders/${selectedOrder.id}/applications`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          message: String(form.get("message")),
          relevantCase: String(form.get("relevantCase")),
          priceCents: price > 0 ? price * 100 : undefined,
          duration: String(form.get("duration"))
        })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось отправить отклик"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast("Отклик отправлен");
      ctx.openPane("applications");
    } finally {
      ctx.setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head">
        <div><h2 className="page-title">Вакансии</h2><p className="page-copy">Отклик доступен участнику платформы и создает основу для чата внутри заказа.</p></div>
      </div>
      {selectedOrder ? (
        <form className="panel application-form" onSubmit={apply}>
          <div className="panel-head"><span className="panel-title">Отклик на {selectedOrder.publicId}</span><button className="btn ghost" type="button" onClick={() => setSelectedOrder(null)}>Отмена</button></div>
          <div className="panel-body">
            <div className="form-row"><label>Почему вы подходите</label><textarea name="message" minLength={10} required defaultValue="Подходит мой опыт и портфолио. Готов(а) обсудить бриф и показать релевантные кейсы." /></div>
            <div className="form-grid">
              <div className="form-row"><label>Релевантный кейс</label><input name="relevantCase" type="url" defaultValue={ctx.user.creatorProfile?.portfolioUrl || ""} /></div>
              <div className="form-row"><label>Стоимость, ₽</label><input name="price" type="number" min="1" defaultValue={ctx.user.creatorProfile?.minBudget || 100000} /></div>
              <div className="form-row"><label>Срок</label><input name="duration" required defaultValue={selectedOrder.deadline} /></div>
            </div>
            <button className="btn wine" disabled={ctx.busy}>{ctx.busy ? "Отправляем..." : "Отправить отклик"}</button>
          </div>
        </form>
      ) : null}
      <div className="panel"><div className="panel-body">
        {ctx.orders.length ? ctx.orders.map((order) => {
          const application = appliedByOrder.get(order.id);
          return <JobSnippet key={order.id} order={order} action={application
            ? <span className="status ok">{statusLabel(application.status)}</span>
            : <button className="btn wine" type="button" onClick={() => setSelectedOrder(order)} disabled={ctx.busy}>Откликнуться</button>} />;
        }) : <div className="empty compact">Опубликованных вакансий пока нет.</div>}
      </div></div>
    </>
  );
}

function JobSnippet({ order, action }: { order: Order; action?: React.ReactNode }) {
  return (
    <div className="job">
      <div className="meta">{order.publicId} · {order.category}</div>
      <h3>{order.title}</h3>
      <p>{order.description}</p>
      <div className="job-tags"><span className="chip">{orderInitiatorLabel(order.initiator)}</span><span className="chip">{order.budget}</span><span className="chip">{order.deadline}</span><span className="chip">{statusLabel(order.status)}</span></div>
      {action ? <div style={{ marginTop: 12 }}>{action}</div> : null}
    </div>
  );
}

function CreatorApplications(ctx: PaneContext) {
  return (
    <>
      <div className="page-head">
        <div><h2 className="page-title">Мои отклики</h2><p className="page-copy">Чат появляется только после отклика и открытия коммуникации заказчиком.</p></div>
      </div>
      <div className="panel">
        <div className="panel-body">
          {ctx.applications.length ? ctx.applications.map((application) => (
            <div className="job-card" key={application.id}>
              <div>
                <div className="meta">{application.order?.publicId}</div>
                <h3>{application.order?.title}</h3>
                <p>{application.message}</p>
                <div className="job-tags"><span className={`status ${application.chat ? "ok" : "warn"}`}>{application.chat ? "Чат открыт" : statusLabel(application.status)}</span>{application.duration ? <span className="chip">{application.duration}</span> : null}{application.priceCents ? <span className="chip">{formatMoney(application.priceCents)}</span> : null}</div>
              </div>
              <div className="job-actions">{application.chat ? <button className="btn wine" onClick={() => ctx.openChat(application.chat!.id)}>Открыть чат</button> : <span className="status warn">На рассмотрении</span>}</div>
            </div>
          )) : <div className="empty">Откликов пока нет.</div>}
        </div>
      </div>
    </>
  );
}

function InvitesPane(ctx: PaneContext) {
  async function decide(invitation: Invitation, status: "ACCEPTED" | "DECLINED") {
    ctx.setBusy(true);
    try {
      const response = await fetch(`/api/invitations/${invitation.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ status })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось обработать приглашение"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast(status === "ACCEPTED" ? "Приглашение принято, отклик создан" : "Приглашение отклонено");
    } finally {
      ctx.setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Приглашения</h2><p className="page-copy">Заказчики могут пригласить вас откликнуться на конкретный заказ.</p></div></div>
      <div className="panel"><div className="panel-body">
        {ctx.invitations.length ? ctx.invitations.map((invitation) => (
          <div className="job-card" key={invitation.id}>
            <div>
              <div className="meta">Приглашение · {invitation.order.publicId}</div>
              <h3>{invitation.order.title}</h3>
              <p>{invitation.message}</p>
              <div className="job-tags"><span className="chip">{invitation.order.budget}</span><span className="chip">{invitation.order.deadline}</span><span className={`status ${invitation.status === "ACCEPTED" ? "ok" : "warn"}`}>{statusLabel(invitation.status)}</span></div>
            </div>
            {invitation.status === "SENT" ? <div className="job-actions"><button className="btn wine" onClick={() => decide(invitation, "ACCEPTED")} disabled={ctx.busy}>Принять</button><button className="btn" onClick={() => decide(invitation, "DECLINED")} disabled={ctx.busy}>Отклонить</button></div> : null}
          </div>
        )) : <div className="empty compact">Новых приглашений пока нет.</div>}
      </div></div>
    </>
  );
}

function CommunityPane() {
  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Сообщество</h2><p className="page-copy">Закрытая среда для одобренных креаторов.</p></div></div>
      <div className="topic-grid">
        <div className="topic"><div className="meta">46 сообщений</div><h3>General</h3><p>Новости и жизнь сообщества.</p></div>
        <div className="topic"><div className="meta">8 новых</div><h3>Запросы</h3><p>Помощь, контакты и экспертиза.</p></div>
        <div className="topic"><div className="meta">5 новых</div><h3>Рекомендации</h3><p>Люди, сервисы и площадки.</p></div>
        <div className="topic"><div className="meta">online</div><h3>Болталка</h3><p>Неформальное общение.</p></div>
        <div className="topic"><div className="meta">74 материала</div><h3>База знаний</h3><p>Гайды, кейсы и шаблоны.</p></div>
      </div>
    </>
  );
}

function KnowledgePane() {
  const articles = [
    {
      category: "Юридическое",
      title: "Договор креатора",
      summary: "Права, этапы и защита результата.",
      body: "Зафиксируйте предмет работ, количество итераций, сроки приемки и порядок передачи исключительных прав. Отдельно перечислите исходники и форматы, которые входят в результат.",
      checklist: "Бриф и приложения · Этапы и критерии приемки · Лимит правок · Оплата и налоги · Права на результат"
    },
    {
      category: "Портфолио",
      title: "Сильный кейс",
      summary: "Контекст, решение и результат.",
      body: "Начните с задачи клиента и ограничений, затем покажите ход решения и свою роль. Завершите измеримым результатом или ясным описанием эффекта для продукта.",
      checklist: "Контекст · Ваша роль · Процесс · Финальный результат · Метрики или отзыв"
    },
    {
      category: "AI",
      title: "AI в продакшне",
      summary: "Практические сценарии работы с API-инструментами.",
      body: "Разделяйте прототип и production-процесс: проверяйте права на входные данные, фиксируйте версии моделей, сохраняйте логи и предусматривайте ручную проверку результата.",
      checklist: "Политика данных · Версия модели · Контроль качества · Логи · Резервный сценарий"
    }
  ];
  const [selectedArticle, setSelectedArticle] = useState<(typeof articles)[number] | null>(null);

  if (selectedArticle) {
    return (
      <>
        <div className="order-back"><button className="btn ghost" type="button" onClick={() => setSelectedArticle(null)}><ArrowLeft size={16} /> База знаний</button></div>
        <div className="page-head"><div><div className="meta">{selectedArticle.category}</div><h2 className="page-title">{selectedArticle.title}</h2><p className="page-copy">{selectedArticle.summary}</p></div></div>
        <article className="panel knowledge-article"><div className="panel-body"><p>{selectedArticle.body}</p><div className="order-section"><h4>Чек-лист</h4><p>{selectedArticle.checklist}</p></div></div></article>
      </>
    );
  }

  return (
    <>
      <div className="page-head"><div><h2 className="page-title">База знаний</h2><p className="page-copy">Практические материалы, шаблоны и записи.</p></div></div>
      <div className="grid three">
        {articles.map((article) => <div className="profile-card" key={article.title}><div className="meta">{article.category}</div><h3 style={{ marginTop: 20 }}>{article.title}</h3><p>{article.summary}</p><button className="btn" type="button" onClick={() => setSelectedArticle(article)}>Открыть</button></div>)}
      </div>
    </>
  );
}

function ClientOverview(ctx: PaneContext) {
  const activeOrders = ctx.orders.filter((order) => !["COMPLETED", "ARCHIVED", "REJECTED"].includes(order.status));
  const newApplications = ctx.applications.filter((application) => application.status === "SENT");
  const latestApplication = ctx.applications[0];
  const latestAiOrder = ctx.orders.find((order) => order.aiMatches?.length);

  return (
    <>
      <div className="page-head">
        <div><h2 className="page-title">{ctx.user.clientProfile?.companyName || "Компания"}</h2><p className="page-copy">Заказы, отклики, AI-рекомендации и доступ к базе.</p></div>
        <button className="btn wine" onClick={() => ctx.openPane("newOrder")}><Plus size={16} /> Новый заказ</button>
      </div>
      <div className="summary">
        <div className="metric"><span>Активные заказы</span><b>{activeOrders.length}</b></div>
        <div className="metric"><span>Новые отклики</span><b>{newApplications.length}</b></div>
        <div className="metric"><span>AI-подборы готовы</span><b>{ctx.orders.filter((order) => order.aiMatches?.length).length}</b></div>
        <div className="metric"><span>Чаты по заказам</span><b>{ctx.chats.length}</b></div>
      </div>
      <div style={{ height: 14 }} />
      <div className="grid two">
        <div className="panel"><div className="panel-head"><span className="panel-title">Последняя активность</span></div><div className="panel-body">
          {latestApplication ? <div className="feed-item"><div className="meta">{latestApplication.order?.publicId}</div><h3>Отклик от {latestApplication.creatorProfile?.firstName} {latestApplication.creatorProfile?.lastName}</h3><p>{latestApplication.order?.title}</p></div> : null}
          {latestAiOrder ? <div className="feed-item"><div className="meta">{latestAiOrder.publicId}</div><h3>AI-топ-3 готов</h3><p>{latestAiOrder.title}</p></div> : null}
          {!latestApplication && !latestAiOrder ? <div className="empty compact">Новых событий пока нет.</div> : null}
        </div></div>
        <AiBox order={latestAiOrder || activeOrders[0]} />
      </div>
    </>
  );
}

function AiBox({ order, onProfile }: { order?: Order; onProfile?: (creator: CreatorProfile) => void }) {
  return (
    <div className="ai-box">
      <div className="meta">{order?.publicId || "ORD"}</div>
      <h3>Топ-3 креатора</h3>
      <p>{order ? `Подбор только для заказа «${order.title}».` : "Выберите заказ, чтобы сформировать подбор."}</p>
      {order?.aiMatches?.length ? order.aiMatches.map((match) => (
        <div className="ai-person" key={match.id}>
          <div className="avatar">{initials(`${match.creatorProfile.firstName} ${match.creatorProfile.lastName}`)}</div>
          <div><b>{match.rank}. {match.creatorProfile.firstName} {match.creatorProfile.lastName}</b><div className="meta">{match.creatorProfile.primaryRole}</div></div>
          <span className="score">{match.score}%</span>
          <small className="ai-rationale">{match.rationale}</small>
          {onProfile ? <button className="btn ghost ai-profile-action" type="button" onClick={() => onProfile(match.creatorProfile)}>Профиль</button> : null}
        </div>
      )) : <div className="notice">AI-подбор еще не запускался.</div>}
    </div>
  );
}

function CompanyOnboarding(ctx: PaneContext) {
  const profile = ctx.user.clientProfile;

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    ctx.setBusy(true);
    try {
      const response = await fetch("/api/profiles/client", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          companyName: String(form.get("companyName")),
          website: String(form.get("website")),
          industry: String(form.get("industry")),
          description: String(form.get("description")),
          contactName: String(form.get("contactName")),
          contactTitle: String(form.get("contactTitle")),
          legalType: String(form.get("legalType")),
          inn: String(form.get("inn")),
          email: String(form.get("email"))
        })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось сохранить карточку"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast("Карточка компании сохранена");
    } finally {
      ctx.setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Карточка компании</h2><p className="page-copy">Данные компании перед созданием и оплатой заказа.</p></div><span className="status ok">Доступна</span></div>
      <form className="panel" onSubmit={submit}><div className="panel-body">
        <div className="form-section"><h3>Компания</h3><div className="form-grid">
          <div className="form-row"><label>Логотип</label><div className="upload">Загрузить логотип</div></div>
          <div><div className="form-row"><label>Название</label><input name="companyName" defaultValue={profile?.companyName || "NORTH STUDIO"} /></div><div className="form-row"><label>Сайт</label><input name="website" defaultValue={profile?.website || "north.example"} /></div><div className="form-row"><label>Отрасль</label><input name="industry" defaultValue={profile?.industry || "Fashion / E-commerce"} /></div></div>
          <div className="form-row full"><label>Описание компании</label><textarea name="description" defaultValue={profile?.description || "Независимый бренд и digital-команда."} /></div>
        </div></div>
        <div className="form-section"><h3>Контактное лицо</h3><div className="form-grid">
          <div className="form-row"><label>Имя</label><input name="contactName" defaultValue={profile?.contactName || "Никита Романов"} /></div>
          <div className="form-row"><label>Должность</label><input name="contactTitle" defaultValue={profile?.contactTitle || "Founder"} /></div>
          <div className="form-row"><label>Telegram</label><input value={`@${ctx.user.telegramUsername || "northfounder"}`} disabled /></div>
          <div className="form-row"><label>Email</label><input name="email" type="email" defaultValue={ctx.user.email || ""} placeholder="hello@company.ru" /></div>
        </div></div>
        <div className="form-section"><h3>Реквизиты</h3><div className="form-grid"><div className="form-row"><label>Тип</label><SelectControl name="legalType" defaultValue={profile?.legalType || "Юридическое лицо"}><option>Юридическое лицо</option><option>ИП</option><option>Самозанятый</option></SelectControl></div><div className="form-row"><label>ИНН</label><input name="inn" defaultValue={profile?.inn || "7700000000"} /></div></div></div>
        <button className="btn wine" disabled={ctx.busy}>Сохранить карточку</button>
      </div></form>
    </>
  );
}

function NewOrderPane(ctx: PaneContext) {
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    ctx.setBusy(true);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          title: String(form.get("title")),
          category: String(form.get("category")),
          description: String(form.get("description")),
          requirements: String(form.get("requirements")),
          budget: String(form.get("budget")),
          deadline: String(form.get("deadline")),
          initiator: String(form.get("initiator"))
        })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось создать заказ"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast(ctx.flags.moderationRequired ? "Заказ отправлен на модерацию" : "Заказ опубликован");
      ctx.openPane("orders");
    } finally {
      ctx.setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Создать заказ</h2><p className="page-copy">Опишите задачу и укажите, от чьего имени опубликован запрос.</p></div></div>
      <form className="panel" onSubmit={submit}><div className="panel-body">
        <div className="form-grid"><div className="form-row"><label>Название</label><input name="title" minLength={3} required placeholder="Например, айдентика для нового бренда" /></div><div className="form-row"><label>Категория</label><SelectControl name="category" defaultValue="Дизайн"><option>Дизайн</option><option>Видео</option><option>Тексты</option><option>Маркетинг</option><option>Креатив</option><option>AI</option><option>Менеджмент</option></SelectControl></div></div>
        <div className="form-row"><label>От кого заказ</label><SelectControl name="initiator" defaultValue="CLIENT"><option value="CLIENT">От заказчика</option><option value="CREATOR">От креатора</option></SelectControl></div>
        <div className="form-row"><label>Описание и ожидаемый результат</label><textarea name="description" minLength={10} required placeholder="Опишите задачу, контекст и ожидаемый результат" /></div>
        <div className="form-grid"><div className="form-row"><label>Бюджет</label><input name="budget" required placeholder="Например, 180–250 тыс. ₽" /></div><div className="form-row"><label>Срок</label><input name="deadline" required placeholder="Например, 3 недели" /></div></div>
        <div className="form-row"><label>Требования</label><textarea name="requirements" minLength={3} required placeholder="Опыт, навыки, обязательные материалы" /></div>
        <button className="btn wine" disabled={ctx.busy}>{ctx.flags.moderationRequired ? "Сохранить и отправить на модерацию" : "Сохранить и опубликовать"}</button>
      </div></form>
    </>
  );
}

async function runAiForOrder(ctx: PaneContext, order: Order) {
  ctx.setBusy(true);
  try {
    const response = await fetch("/api/ai/match", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ orderId: order.id })
    });
    if (!response.ok) {
      ctx.showToast(await responseError(response, "Не удалось обновить рекомендации"));
      return;
    }
    await ctx.refreshAll();
    ctx.showToast(`AI-топ-3 для ${order.publicId} обновлен`);
  } finally {
    ctx.setBusy(false);
  }
}

async function openApplicationChat(ctx: PaneContext, application: Application) {
  ctx.setBusy(true);
  try {
    const response = await fetch("/api/chats", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ applicationId: application.id })
    });
    if (!response.ok) {
      ctx.showToast(await responseError(response, "Не удалось открыть чат"));
      return;
    }
    const data = (await response.json()) as { chat: Chat };
    await ctx.refreshAll();
    ctx.showToast(application.chat ? "Чат открыт" : "Чат создан внутри заказа");
    ctx.openChat(data.chat.id);
  } finally {
    ctx.setBusy(false);
  }
}

function ClientOrders(ctx: PaneContext) {
  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Мои заказы</h2><p className="page-copy">Откройте заказ, чтобы увидеть только его отклики, AI-рекомендации и чаты.</p></div><button className="btn wine" onClick={() => ctx.openPane("newOrder")}>Новый заказ</button></div>
      <div style={{ display: "grid", gap: 12 }}>{ctx.orders.length ? ctx.orders.map((order) => (
        <div className="job-card" key={order.id}>
          <div><div className="meta">{order.publicId} · {order.category}</div><h3>{order.title}</h3><p>{order.description}</p><div className="job-tags"><span className={`status ${order.status === "PUBLISHED" ? "ok" : "warn"}`}>{statusLabel(order.status)}</span><span className="chip">{orderInitiatorLabel(order.initiator)}</span><span className="chip">{order._count?.applications || order.applications?.length || 0} откликов</span><span className="chip">Рекомендации: {order.aiMatches?.length || 0}</span><span className="chip">{order.budget}</span></div></div>
          <div className="job-actions"><button className="btn wine" onClick={() => ctx.openOrder(order.id)}>Открыть заказ</button></div>
        </div>
      )) : <div className="empty">Заказов пока нет. Создайте первый бриф.</div>}</div>
    </>
  );
}

function ApplicationRow({
  application,
  ctx,
  onProfile,
  showOrderLink
}: {
  application: Application;
  ctx: PaneContext;
  onProfile: (creator: CreatorProfile) => void;
  showOrderLink?: boolean;
}) {
  const creator = application.creatorProfile;
  if (!creator) return null;

  return (
    <div className="application">
      <div className="avatar">{initials(`${creator.firstName} ${creator.lastName}`)}</div>
      <div className="application-main">
        <b>{creator.firstName} {creator.lastName}</b>
        {application.order ? <div className="meta">{application.order.publicId} · {application.order.title}</div> : null}
        <div className="application-copy">{application.message}</div>
        <div className="job-tags">
          <span className="chip">{creator.primaryRole} · {creator.level}</span>
          {application.priceCents ? <span className="chip">{formatMoney(application.priceCents)}</span> : null}
          {application.duration ? <span className="chip">{application.duration}</span> : null}
          <span className={`status ${application.chat ? "ok" : "warn"}`}>{statusLabel(application.status)}</span>
        </div>
      </div>
      <div className="actions">
        {showOrderLink && application.order ? <button className="btn" type="button" onClick={() => ctx.openOrder(application.order!.id)}>Заказ</button> : null}
        <button className="btn" type="button" onClick={() => onProfile(creator)}>Профиль</button>
        <button className="btn wine" type="button" onClick={() => void openApplicationChat(ctx, application)} disabled={ctx.busy}>{application.chat ? "Открыть чат" : "Начать чат"}</button>
      </div>
    </div>
  );
}

function ClientOrderDetail(ctx: PaneContext) {
  const [selectedCreator, setSelectedCreator] = useState<CreatorProfile | null>(null);
  const order = ctx.orders.find((item) => item.id === ctx.selectedOrderId);

  if (!order) {
    return (
      <>
        <div className="page-head"><div><h2 className="page-title">Заказ не найден</h2><p className="page-copy">Возможно, он был удален или не принадлежит вашему аккаунту.</p></div></div>
        <button className="btn" type="button" onClick={() => ctx.openPane("orders")}><ArrowLeft size={16} /> К списку заказов</button>
      </>
    );
  }

  const orderApplications = ctx.applications.filter((application) => application.order?.id === order.id);
  const orderChats = ctx.chats.filter((chat) => chat.order.id === order.id);
  const aiDisabled = ["COMPLETED", "ARCHIVED", "REJECTED"].includes(order.status);

  return (
    <>
      <div className="order-back">
        <button className="btn ghost" type="button" onClick={() => ctx.openPane("orders")}><ArrowLeft size={16} /> Мои заказы</button>
      </div>
      <div className="page-head">
        <div><div className="meta">{order.publicId} · {order.category} · {orderInitiatorLabel(order.initiator)}</div><h2 className="page-title">{order.title}</h2><p className="page-copy">Все данные ниже относятся только к этому заказу.</p></div>
        <div className="inline-actions">
          <span className={`status ${order.status === "PUBLISHED" ? "ok" : "warn"}`}>{statusLabel(order.status)}</span>
          <button className="btn wine" type="button" onClick={() => void runAiForOrder(ctx, order)} disabled={ctx.busy || aiDisabled}><Bot size={16} /> {order.aiMatches?.length ? "Обновить AI-топ-3" : "Подобрать AI-топ-3"}</button>
        </div>
      </div>

      <div className="summary order-summary">
        <div className="metric"><span>Отклики</span><b>{orderApplications.length}</b></div>
        <div className="metric"><span>AI-рекомендации</span><b>{order.aiMatches?.length || 0}</b></div>
        <div className="metric"><span>Чаты</span><b>{orderChats.length}</b></div>
      </div>

      <div className="order-detail">
        <section className="order-info">
          <div className="job-tags"><span className="chip">{orderInitiatorLabel(order.initiator)}</span><span className="chip">{order.budget}</span><span className="chip">{order.deadline}</span></div>
          <div className="order-section"><h4>Задача</h4><p>{order.description}</p></div>
          <div className="order-section"><h4>Требования</h4><p>{order.requirements}</p></div>
          {orderChats.length ? <div className="order-section"><h4>Диалоги по заказу</h4><div className="order-chat-links">{orderChats.map((chat) => <button className="btn" type="button" key={chat.id} onClick={() => ctx.openChat(chat.id)}>{chat.creatorProfile.firstName} {chat.creatorProfile.lastName}</button>)}</div></div> : null}
        </section>
        <AiBox order={order} onProfile={setSelectedCreator} />
      </div>

      <div className="panel order-responses">
        <div className="panel-head"><span className="panel-title">Все отклики на {order.publicId}</span><span className="result-count">{orderApplications.length}</span></div>
        <div className="panel-body">
          {orderApplications.length ? orderApplications.map((application) => <ApplicationRow key={application.id} application={application} ctx={ctx} onProfile={setSelectedCreator} />) : <div className="empty compact">На этот заказ откликов пока нет.</div>}
        </div>
      </div>
      <CreatorProfileDialog creator={selectedCreator} canSeeContacts onClose={() => setSelectedCreator(null)} />
    </>
  );
}

function ClientResponses(ctx: PaneContext) {
  const [selectedCreator, setSelectedCreator] = useState<CreatorProfile | null>(null);

  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Все отклики</h2><p className="page-copy">Общая лента по компании. Для работы с конкретной заявкой перейдите в ее заказ.</p></div></div>
      <div className="panel"><div className="panel-body">
        {ctx.applications.length ? ctx.applications.map((application) => <ApplicationRow key={application.id} application={application} ctx={ctx} onProfile={setSelectedCreator} showOrderLink />) : <div className="empty">Откликов пока нет.</div>}
      </div></div>
      <CreatorProfileDialog creator={selectedCreator} canSeeContacts onClose={() => setSelectedCreator(null)} />
    </>
  );
}

function ClientCatalog(ctx: PaneContext) {
  const publishedOrders = ctx.orders.filter((order) => order.status === "PUBLISHED");
  const [selectedOrderId, setSelectedOrderId] = useState(publishedOrders[0]?.id || "");
  const canSeeContacts = !ctx.flags.paymentsRequired || Boolean(ctx.user.clientProfile?.hasDatabaseAccess);
  const invitedKeys = new Set(ctx.invitations.map((item) => `${item.order.id}:${item.creatorProfile.id}`));

  useEffect(() => {
    if (!selectedOrderId && publishedOrders[0]) setSelectedOrderId(publishedOrders[0].id);
  }, [selectedOrderId, publishedOrders]);

  async function invite(creator: CreatorProfile) {
    if (!selectedOrderId) {
      ctx.showToast("Сначала опубликуйте заказ");
      return;
    }

    ctx.setBusy(true);
    try {
      const response = await fetch("/api/invitations", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          orderId: selectedOrderId,
          creatorProfileId: creator.id,
          message: `Ваш профиль подходит для нашего заказа. Предлагаем откликнуться и обсудить задачу внутри CREATIN.WORLD.`
        })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось отправить приглашение"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast(`Приглашение для ${creator.firstName} отправлено`);
    } finally {
      ctx.setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head">
        <div><h2 className="page-title">Каталог креаторов</h2><p className="page-copy">{canSeeContacts ? "Контакты доступны в текущем режиме. Приглашение всегда связано с опубликованным заказом." : "Контакты скрыты. Для полного доступа нужен пакет с базой."}</p></div>
        <button className="btn" onClick={() => ctx.openPane("payments")}>Изменить пакет</button>
      </div>
      <div className="catalog-actionbar">
        <label htmlFor="invite-order">Заказ для приглашения</label>
        <SelectControl id="invite-order" value={selectedOrderId} onChange={(event) => setSelectedOrderId(event.target.value)}>
          {publishedOrders.length ? publishedOrders.map((order) => <option value={order.id} key={order.id}>{order.publicId} · {order.title}</option>) : <option value="">Нет опубликованных заказов</option>}
        </SelectControl>
      </div>
      <CreatorCatalog
        scope="client"
        canSeeContacts={canSeeContacts}
        renderAction={(creator) => {
          const alreadyInvited = invitedKeys.has(`${selectedOrderId}:${creator.id}`);
          return <button className="btn wine" type="button" onClick={() => invite(creator)} disabled={ctx.busy || !selectedOrderId || alreadyInvited}>{alreadyInvited ? "Приглашен" : "Пригласить"}</button>;
        }}
      />
    </>
  );
}

function PaymentPane(ctx: PaneContext & { packages: PackagePlan[] }) {
  const [selectedPackage, setSelectedPackage] = useState(ctx.packages[0]?.id || "");

  async function pay() {
    ctx.setBusy(true);
    try {
      const response = await fetch("/api/payments/test", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ purpose: "client_package", packageId: selectedPackage })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось активировать пакет"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast(ctx.flags.paymentsRequired ? "Тестовый платеж создан" : "Тестовый пакет активирован");
      ctx.openPane("catalog");
    } finally {
      ctx.setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Оплата и пакеты</h2><p className="page-copy">{ctx.flags.paymentsRequired ? "Выберите подходящий пакет. Доступ откроется после подтверждения оплаты." : "На текущем этапе пакет активируется сразу после выбора."}</p></div></div>
      <div className="package-grid">{ctx.packages.map((item) => (
        <button className={`package ${selectedPackage === item.id ? "selected" : ""}`} key={item.id} onClick={() => setSelectedPackage(item.id)}>
          <div className="meta">{item.placements ? `${item.placements} размещ.` : "Пакет"}</div>
          <h3>{item.title}</h3>
          <p>{item.description}</p>
          <div className="price">{formatMoney(item.priceCents)}</div>
          <ul><li>AI-топ-3 после публикации</li><li>Контакты откликнувшихся</li><li>{item.databaseAccess ? "Контакты всей базы" : "Без контактов всей базы"}</li></ul>
        </button>
      ))}</div>
      <div className="panel" style={{ marginTop: 14 }}><div className="panel-body"><button className="btn wine" onClick={pay} disabled={ctx.busy || !selectedPackage}>{ctx.flags.paymentsRequired ? "Перейти к оплате" : "Активировать пакет"}</button></div></div>
    </>
  );
}

function ChatPane(ctx: PaneContext) {
  const activeChat = ctx.chats.find((chat) => chat.id === ctx.activeChatId) || ctx.chats[0];
  const [body, setBody] = useState("");
  const counterpart = activeChat
    ? ctx.user.role === "CREATOR"
      ? activeChat.clientProfile.companyName
      : `${activeChat.creatorProfile.firstName} ${activeChat.creatorProfile.lastName}`
    : "";

  useEffect(() => {
    setBody("");
  }, [activeChat?.id]);

  async function send(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();
    if (!activeChat || !body.trim()) return;
    ctx.setBusy(true);
    try {
      const response = await fetch(`/api/chats/${activeChat.id}/messages`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ body })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось отправить сообщение"));
        return;
      }
      setBody("");
      await ctx.refreshAll();
    } finally {
      ctx.setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Чаты по заказам</h2><p className="page-copy">Свободных личных сообщений нет. Каждый чат связан с конкретным заказом и откликом.</p></div></div>
      {activeChat ? (
        <div className="chat">
          <div className="chat-list">
            {ctx.chats.map((chat) => {
              const lastMessage = chat.messages.at(-1);
              const chatName = ctx.user.role === "CREATOR"
                ? chat.clientProfile.companyName
                : `${chat.creatorProfile.firstName} ${chat.creatorProfile.lastName}`;
              return (
                <button className={`chat-person ${chat.id === activeChat.id ? "active" : ""}`} type="button" key={chat.id} onClick={() => ctx.openChat(chat.id)}>
                  <span className="chat-person-top"><b>{chatName}</b><time>{lastMessage ? new Date(lastMessage.createdAt).toLocaleDateString("ru-RU", { day: "2-digit", month: "short" }) : ""}</time></span>
                  <small>{chat.order.publicId} · {chat.order.title}</small>
                  <span className="chat-preview">{lastMessage ? `${lastMessage.senderId === ctx.user.id ? "Вы: " : ""}${lastMessage.body}` : "Сообщений пока нет"}</span>
                </button>
              );
            })}
          </div>
          <div className="chat-window">
            <div className="chat-order">
              <div><b>{counterpart}</b><span>{activeChat.order.publicId} · {activeChat.order.title}</span></div>
              <div className="chat-order-meta"><span className="status ok">{statusLabel(activeChat.application.status)}</span>{activeChat.application.priceCents ? <span className="chip">{formatMoney(activeChat.application.priceCents)}</span> : null}</div>
            </div>
            <div className="messages">
              {activeChat.messages.length ? activeChat.messages.map((message) => <div className={`bubble ${message.senderId === ctx.user.id ? "me" : ""}`} key={message.id}><small>{message.senderId === ctx.user.id ? "Вы" : message.sender.name} · {new Date(message.createdAt).toLocaleString("ru-RU", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</small><span>{message.body}</span></div>) : <div className="chat-empty">Начните обсуждение этого отклика и заказа.</div>}
            </div>
            <form className="composer" onSubmit={send}><input value={body} onChange={(event) => setBody(event.target.value)} maxLength={4000} placeholder="Сообщение по заказу" aria-label="Сообщение по заказу" /><button className="btn wine" disabled={ctx.busy || !body.trim()}>Отправить</button></form>
          </div>
        </div>
      ) : (
        <div className="empty">Чаты появятся после отклика креатора и открытия коммуникации заказчиком.</div>
      )}
    </>
  );
}

function SettingsPane(ctx: PaneContext) {
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    ctx.setBusy(true);
    try {
      const response = await fetch("/api/settings", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          email: String(form.get("email")),
          notificationPreference: String(form.get("notificationPreference"))
        })
      });
      if (!response.ok) {
        ctx.showToast(await responseError(response, "Не удалось сохранить настройки"));
        return;
      }
      await ctx.refreshAll();
      ctx.showToast("Настройки сохранены");
    } finally {
      ctx.setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head"><div><h2 className="page-title">Настройки</h2><p className="page-copy">Telegram, уведомления и безопасность аккаунта.</p></div></div>
      <form className="panel" onSubmit={submit}><div className="panel-body">
        <div className="form-row"><label>Telegram</label><input value={`@${ctx.user.telegramUsername || "telegram"}`} disabled /></div>
        <div className="form-row"><label>Email для документов и уведомлений</label><input name="email" type="email" defaultValue={ctx.user.email || ""} placeholder="name@example.com" /></div>
        <div className="form-row"><label>Уведомления</label><SelectControl name="notificationPreference" defaultValue={ctx.user.notificationPreference || "telegram"}><option value="telegram">Telegram + внутри платформы</option><option value="platform">Только внутри платформы</option></SelectControl></div>
        <div className="form-row"><label>Тема интерфейса</label><ThemeControl /></div>
        <button className="btn wine" disabled={ctx.busy} style={{ marginTop: 12 }}>{ctx.busy ? "Сохраняем..." : "Сохранить"}</button>
      </div></form>
    </>
  );
}
