import Link from "next/link";
import { HomeStats } from "@/components/brand/HomeStats";

export default function HomePage() {
  return (
    <>
      <section className="hero">
        <div>
          <div className="eyebrow">Профессиональная платформа креативного рынка</div>
          <h1>
            Работай с <span>сильнейшими.</span>
          </h1>
          <p className="hero-lead">
            Проверенные специалисты, качественные заказы, закрытое сообщество и AI-подбор
            исполнителей для каждого проекта в одной экосистеме.
          </p>
          <div className="hero-actions">
            <Link className="btn wine" href="/login?role=creator">
              Стать креатором
            </Link>
            <Link className="btn" href="/login?role=client">
              Разместить заказ
            </Link>
          </div>
        </div>
        <div className="hero-bottom">
          <HomeStats />
          <div className="hero-note">
            От публикации брифа до выбора исполнителя и рабочего диалога внутри заказа.
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div>
            <div className="eyebrow">Один продукт</div>
            <h2>Разные кабинеты для разных задач</h2>
          </div>
          <p className="section-copy">
            Интерфейс автоматически перестраивается под роль. Креатор не видит создание
            заказов и оплату размещений. Заказчик не видит отклик на вакансии и
            профессиональную анкету креатора.
          </p>
        </div>
        <div className="ecosystem">
          <article className="eco">
            <span className="num">01</span>
            <h3>Креатор</h3>
            <p>Анкета, вступление, вакансии, отклики, приглашения и чаты по заказам.</p>
          </article>
          <article className="eco">
            <span className="num">02</span>
            <h3>Заказчик</h3>
            <p>Компания, пакеты размещения, заказы, AI-топ-3, отклики и контакты.</p>
          </article>
          <article className="eco">
            <span className="num">03</span>
            <h3>Админка</h3>
            <p>Модерация, заказы, пользователи, платежи и контроль рекомендаций.</p>
          </article>
        </div>
      </section>
    </>
  );
}
