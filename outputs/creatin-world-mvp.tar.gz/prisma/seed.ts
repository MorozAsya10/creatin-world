import { PrismaClient, Role, CreatorStatus, OrderStatus, ApplicationStatus } from "@prisma/client";
import { generatedCreatorSeed, type CreatorSeed } from "./creator-fixtures";

const prisma = new PrismaClient();

const featuredCreatorSeed: CreatorSeed[] = [
  {
    telegramId: "10001",
    telegramUsername: "annakim",
    firstName: "Анна",
    lastName: "Ким",
    city: "Москва",
    category: "Дизайн",
    primaryRole: "Motion / 3D designer",
    level: "Senior",
    experienceYears: 7,
    expertise: ["3D", "Motion", "Fashion"],
    bio: "Визуальные системы и 3D-ролики для брендов.",
    minBudget: 180000,
    hourlyRate: 10000,
    workFormat: "Проект",
    availability: "available",
    score: 96
  },
  {
    telegramId: "10002",
    telegramUsername: "romanov",
    firstName: "Илья",
    lastName: "Романов",
    city: "Санкт-Петербург",
    category: "Менеджмент",
    primaryRole: "Creative producer",
    level: "Senior",
    experienceYears: 8,
    expertise: ["Production", "Teams", "Strategy"],
    bio: "Команды и проекты от идеи до релиза.",
    minBudget: 220000,
    hourlyRate: 12000,
    workFormat: "Проект",
    availability: "soon",
    score: 94
  },
  {
    telegramId: "10003",
    telegramUsername: "mariav",
    firstName: "Мария",
    lastName: "Волкова",
    city: "Москва",
    category: "Креатив",
    primaryRole: "Art director",
    level: "Senior",
    experienceYears: 6,
    expertise: ["Identity", "Campaigns", "Culture"],
    bio: "Айдентика и кампании с сильным визуальным языком.",
    minBudget: 200000,
    hourlyRate: 11000,
    workFormat: "Part-time",
    availability: "available",
    score: 92
  },
  {
    telegramId: "10004",
    telegramUsername: "denisyun",
    firstName: "Денис",
    lastName: "Юн",
    city: "Тбилиси",
    category: "AI",
    primaryRole: "AI video creator",
    level: "Middle",
    experienceYears: 4,
    expertise: ["Runway", "AI video", "Concept"],
    bio: "Генеративное видео и AI-production.",
    minBudget: 120000,
    hourlyRate: 8000,
    workFormat: "Проект",
    availability: "available",
    score: 89
  },
  {
    telegramId: "10005",
    telegramUsername: "olgasever",
    firstName: "Ольга",
    lastName: "Север",
    city: "Москва",
    category: "Маркетинг",
    primaryRole: "Brand strategist",
    level: "Senior",
    experienceYears: 7,
    expertise: ["Research", "Brand", "Naming"],
    bio: "Позиционирование, исследования и стратегии.",
    minBudget: 160000,
    hourlyRate: 9000,
    workFormat: "Проект",
    availability: "soon",
    score: 88
  },
  {
    telegramId: "10006",
    telegramUsername: "maxlevin",
    firstName: "Макс",
    lastName: "Левин",
    city: "Москва",
    category: "Видео",
    primaryRole: "Director / DOP",
    level: "Senior",
    experienceYears: 9,
    expertise: ["Film", "Ads", "Music"],
    bio: "Реклама, клипы и операторская работа.",
    minBudget: 250000,
    hourlyRate: 14000,
    workFormat: "Проект",
    availability: "available",
    score: 87
  },
  {
    telegramId: "10007",
    telegramUsername: "elenamir",
    firstName: "Елена",
    lastName: "Мир",
    city: "Ереван",
    category: "Тексты",
    primaryRole: "Copywriter",
    level: "Middle",
    experienceYears: 4,
    expertise: ["Tone of voice", "Editorial", "SMM"],
    bio: "Тексты для брендов, медиа и digital-продуктов.",
    minBudget: 80000,
    hourlyRate: 5000,
    workFormat: "Part-time",
    availability: "available",
    score: 84
  },
  {
    telegramId: "10008",
    telegramUsername: "sashali",
    firstName: "Саша",
    lastName: "Ли",
    city: "Алматы",
    category: "Дизайн",
    primaryRole: "UX/UI designer",
    level: "Middle",
    experienceYears: 4,
    expertise: ["UX", "UI", "Product"],
    bio: "Интерфейсы и продуктовые системы.",
    minBudget: 110000,
    hourlyRate: 6000,
    workFormat: "Проект",
    availability: "available",
    score: 81
  }
];

const creatorSeed = [...featuredCreatorSeed, ...generatedCreatorSeed];

async function main() {
  await prisma.message.deleteMany();
  await prisma.chat.deleteMany();
  await prisma.invitation.deleteMany();
  await prisma.application.deleteMany();
  await prisma.aiMatch.deleteMany();
  await prisma.aiLog.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.order.deleteMany();
  await prisma.portfolioFile.deleteMany();
  await prisma.creatorProfile.deleteMany();
  await prisma.clientProfile.deleteMany();
  await prisma.package.deleteMany();
  await prisma.promoCode.deleteMany();
  await prisma.featureFlag.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.user.deleteMany();

  await prisma.featureFlag.createMany({
    data: [
      {
        key: "payments.required",
        enabled: false,
        description: "Доступ открывается только после подтверждения оплаты."
      },
      {
        key: "moderation.required",
        enabled: false,
        description: "Анкеты и заказы требуют ручного решения администратора."
      },
      {
        key: "ai.external_required",
        enabled: false,
        description: "При недоступности внешнего AI резервный подбор не используется."
      }
    ]
  });

  const packages = await Promise.all(
    [
      {
        code: "single",
        title: "Одно размещение",
        description: "Топ-3 AI-рекомендации и контакты всех откликнувшихся.",
        placements: 1,
        databaseAccess: false
      },
      {
        code: "single_db",
        title: "Одно размещение + база",
        description: "Топ-3, контакты откликнувшихся и контакты всей базы креаторов.",
        placements: 1,
        databaseAccess: true
      },
      {
        code: "bundle",
        title: "Пакет размещений",
        description: "Несколько публикаций, топ-3 и контакты откликнувшихся.",
        placements: 5,
        databaseAccess: false
      },
      {
        code: "bundle_db",
        title: "Пакет + база",
        description: "Несколько публикаций и полный доступ к контактам базы.",
        placements: 5,
        databaseAccess: true
      }
    ].map((item) =>
      prisma.package.create({
        data: {
          ...item,
          priceCents: null
        }
      })
    )
  );

  const admin = await prisma.user.create({
    data: {
      telegramId: "90001",
      telegramUsername: "creatin_admin",
      name: "CREATIN Administrator",
      role: Role.ADMIN
    }
  });

  const client = await prisma.user.create({
    data: {
      telegramId: "20001",
      telegramUsername: "northfounder",
      name: "Никита Романов",
      email: "hello@north.example",
      role: Role.CLIENT,
      clientProfile: {
        create: {
          companyName: "NORTH STUDIO",
          website: "north.example",
          industry: "Fashion / E-commerce",
          description: "Независимый бренд и digital-команда.",
          contactName: "Никита Романов",
          contactTitle: "Founder",
          legalType: "Юридическое лицо",
          inn: "7700000000",
          activePackageId: packages[1].id,
          hasDatabaseAccess: true
        }
      }
    },
    include: { clientProfile: true }
  });

  const creators = [];
  for (const item of creatorSeed) {
    const creator = await prisma.user.create({
      data: {
        telegramId: item.telegramId,
        telegramUsername: item.telegramUsername,
        name: `${item.firstName} ${item.lastName}`,
        email: `${item.telegramUsername}@creatin.example`,
        role: Role.CREATOR,
        creatorProfile: {
          create: {
            firstName: item.firstName,
            lastName: item.lastName,
            city: item.city,
            category: item.category,
            primaryRole: item.primaryRole,
            level: item.level,
            experienceYears: item.experienceYears,
            expertise: item.expertise,
            bio: item.bio,
            portfolioUrl: item.portfolioUrl || "https://portfolio.example",
            cases: item.cases || "1. Fashion campaign\n2. 3D product film\n3. Brand launch",
            workFormat: item.workFormat,
            availability: item.availability,
            minBudget: item.minBudget,
            hourlyRate: item.hourlyRate,
            telegramContact: `@${item.telegramUsername}`,
            score: item.score,
            status: CreatorStatus.APPROVED,
            membershipPaid: true,
            isApproved: true
          }
        }
      },
      include: { creatorProfile: true }
    });

    creators.push(creator);
  }

  const order21 = await prisma.order.create({
    data: {
      publicId: "ORD-021",
      clientProfileId: client.clientProfile!.id,
      title: "Айдентика для fashion-бренда",
      category: "Дизайн",
      description: "Нейминг, визуальная система и гайд для запуска первой коллекции.",
      requirements: "Опыт в fashion, сильная типографика, кейсы по айдентике.",
      budget: "180-250 тыс. ₽",
      deadline: "3 недели",
      initiator: "CLIENT",
      status: OrderStatus.PUBLISHED,
      publishedAt: new Date()
    }
  });

  const order20 = await prisma.order.create({
    data: {
      publicId: "ORD-020",
      clientProfileId: client.clientProfile!.id,
      title: "Монтажер Reels на постоянный объем",
      category: "Видео",
      description: "20-25 вертикальных роликов в месяц.",
      requirements: "Чувство ритма, опыт с экспертным контентом.",
      budget: "90-130 тыс. ₽/мес.",
      deadline: "Долгосрочно",
      initiator: "CREATOR",
      status: OrderStatus.PUBLISHED,
      publishedAt: new Date()
    }
  });

  await prisma.order.createMany({
    data: [
      {
        publicId: "ORD-018",
        clientProfileId: client.clientProfile!.id,
        title: "Креативная команда для спецпроекта",
        category: "Креатив",
        description: "Продюсер, арт-директор и motion-дизайнер.",
        requirements: "Опыт комплексных digital-кампаний.",
        budget: "от 450 тыс. ₽",
        deadline: "6 недель",
        initiator: "CLIENT",
        status: OrderStatus.COMPLETED
      }
    ]
  });

  await prisma.invitation.create({
    data: {
      orderId: order20.id,
      creatorProfileId: creators[0].creatorProfile!.id,
      clientProfileId: client.clientProfile!.id,
      message: "Ваш опыт в motion и fashion подходит для регулярного видеопродакшна. Предлагаем обсудить формат работы."
    }
  });

  const application = await prisma.application.create({
    data: {
      orderId: order21.id,
      creatorProfileId: creators[0].creatorProfile!.id,
      status: ApplicationStatus.CHAT_OPEN,
      message: "Подходит мой опыт в fashion motion и запуске визуальных систем.",
      relevantCase: "https://portfolio.example/fashion",
      priceCents: 18000000,
      duration: "3 недели"
    }
  });

  await prisma.application.createMany({
    data: creators.slice(1, 6).map((creator, index) => ({
      orderId: order21.id,
      creatorProfileId: creator.creatorProfile!.id,
      status: index < 2 ? ApplicationStatus.VIEWED : ApplicationStatus.SENT,
      message: "Готов(а) обсудить задачу и показать релевантные кейсы.",
      relevantCase: "https://portfolio.example/case",
      priceCents: (160000 + index * 20000) * 100,
      duration: index % 2 === 0 ? "3 недели" : "4 недели"
    }))
  });

  const chat = await prisma.chat.create({
    data: {
      orderId: order21.id,
      applicationId: application.id,
      clientProfileId: client.clientProfile!.id,
      creatorProfileId: creators[0].creatorProfile!.id
    }
  });

  await prisma.message.createMany({
    data: [
      {
        chatId: chat.id,
        senderId: client.id,
        body: "Привет! Спасибо за отклик. Хотим уточнить доступность на следующей неделе."
      },
      {
        chatId: chat.id,
        senderId: creators[0].id,
        body: "Привет! Свободна со вторника, могу начать с короткого брифа."
      }
    ]
  });

  await prisma.aiMatch.createMany({
    data: creators.slice(0, 3).map((creator, index) => ({
      orderId: order21.id,
      creatorProfileId: creator.creatorProfile!.id,
      rank: index + 1,
      score: creator.creatorProfile!.score,
      rationale: "Seed-рекомендация на основе категории, опыта и портфолио.",
      provider: "seed"
    }))
  });

  await prisma.promoCode.createMany({
    data: [
      { code: "CREATIN100", description: "Демо-промокод для полного доступа на первом этапе.", discountPct: 100 },
      { code: "FOUNDERS", description: "Промокод раннего участника.", discountPct: 50 }
    ]
  });

  await prisma.auditLog.create({
    data: {
      actorId: admin.id,
      action: "seed.created",
      entity: "database",
      payload: {
        creators: creators.length,
        orders: 3,
        applications: 6,
        invitations: 1
      }
    }
  });
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
