import { InvitationStatus, Role } from "@prisma/client";
import { z } from "zod";
import { ok, fail, ApiError } from "@/lib/api";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";

const schema = z.object({
  status: z.enum(["ACCEPTED", "DECLINED"])
});

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireUser([Role.CREATOR]);
    if (!user.creatorProfile) throw new ApiError(400, "Анкета креатора не найдена");

    const { id } = await params;
    const body = schema.parse(await request.json());
    const invitation = await prisma.invitation.findUnique({
      where: { id },
      include: { order: true }
    });

    if (!invitation) throw new ApiError(404, "Приглашение не найдено");
    if (invitation.creatorProfileId !== user.creatorProfile.id) {
      throw new ApiError(403, "Это приглашение адресовано другому креатору");
    }
    if (invitation.status !== InvitationStatus.SENT) {
      throw new ApiError(409, "Решение по приглашению уже принято");
    }

    const updated = await prisma.$transaction(async (tx) => {
      const nextInvitation = await tx.invitation.update({
        where: { id: invitation.id },
        data: { status: body.status }
      });

      if (body.status === "ACCEPTED") {
        await tx.application.upsert({
          where: {
            orderId_creatorProfileId: {
              orderId: invitation.orderId,
              creatorProfileId: invitation.creatorProfileId
            }
          },
          update: {},
          create: {
            orderId: invitation.orderId,
            creatorProfileId: invitation.creatorProfileId,
            status: "SENT",
            message: `Принимаю приглашение на заказ «${invitation.order.title}». Готов(а) обсудить детали.`,
            relevantCase: user.creatorProfile?.portfolioUrl,
            duration: invitation.order.deadline
          }
        });
      }

      return nextInvitation;
    });

    return ok({ invitation: updated });
  } catch (error) {
    return fail(error);
  }
}
