import { Role } from "@prisma/client";
import { z } from "zod";
import { ok, fail, ApiError } from "@/lib/api";
import { createTestPayment } from "@/lib/payments";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";

const paymentSchema = z.object({
  purpose: z.enum(["creator_membership", "client_package"]),
  packageId: z.string().optional(),
  amountCents: z.number().int().positive().optional()
});

export async function POST(request: Request) {
  try {
    const user = await requireUser([Role.CREATOR, Role.CLIENT, Role.ADMIN]);
    const body = paymentSchema.parse(await request.json());

    if (body.purpose === "creator_membership") {
      if (!user.creatorProfile) throw new ApiError(400, "Creator profile is required");
      const payment = await createTestPayment({
        userId: user.id,
        creatorProfileId: user.creatorProfile.id,
        amountCents: body.amountCents
      });
      return ok({ payment }, { status: 201 });
    }

    if (!body.packageId) throw new ApiError(400, "packageId is required");
    const selectedPackage = await prisma.package.findUnique({ where: { id: body.packageId } });
    if (!selectedPackage) throw new ApiError(404, "Package not found");

    const clientProfile =
      user.role === Role.CLIENT
        ? user.clientProfile
        : await prisma.clientProfile.findFirst({ orderBy: { createdAt: "asc" } });

    if (!clientProfile) throw new ApiError(400, "Client profile is required");

    const payment = await createTestPayment({
      userId: user.id,
      clientProfileId: clientProfile.id,
      packageId: selectedPackage.id,
      amountCents: selectedPackage.priceCents || body.amountCents
    });

    return ok({ payment }, { status: 201 });
  } catch (error) {
    return fail(error);
  }
}
