import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/brand/Header";

export const metadata: Metadata = {
  title: "CREATIN.WORLD",
  description: "Платформа для креаторов и заказчиков."
};

const themeScript = `
  try {
    var savedTheme = localStorage.getItem("creatin-world-theme");
    var theme = savedTheme === "light" || savedTheme === "dark"
      ? savedTheme
      : (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark");
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
  } catch (_) {
    document.documentElement.dataset.theme = "dark";
  }
`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" data-theme="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>
        <Header />
        <main>{children}</main>
      </body>
    </html>
  );
}
