import { Role } from "@prisma/client";

import { ApiError, fail, ok } from "@/lib/api";
import { upsertGeneratedCreators } from "@/lib/demo-creators";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";

export async function POST() {
  try {
    if (process.env.NODE_ENV === "production") {
      throw new ApiError(404, "Not found");
    }

    await requireUser([Role.ADMIN]);
    return ok(await upsertGeneratedCreators(prisma));
  } catch (error) {
    return fail(error);
  }
}
