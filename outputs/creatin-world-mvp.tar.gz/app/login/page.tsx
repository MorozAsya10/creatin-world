import { Suspense } from "react";
import { TelegramLogin } from "@/components/auth/TelegramLogin";

export default function LoginPage() {
  const demoEnabled = process.env.TELEGRAM_AUTH_BYPASS === "true";

  return (
    <Suspense fallback={<div className="auth-screen"><div className="loading">Загрузка входа...</div></div>}>
      <TelegramLogin demoEnabled={demoEnabled} />
    </Suspense>
  );
}
